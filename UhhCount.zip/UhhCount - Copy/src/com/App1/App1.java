package com.App1;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class App1 {
    private static int count = 0;
    private JButton button1;
    private JPanel panel1;
    private JTextArea textArea1;
    private JTextPane countTheTimesMarshTextPane;

    public App1() {
        // initilize
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                count++;
                textArea1.setEditable(false);
                textArea1.setText(String.valueOf(count));
            }
        });
    }
    public static void main(String[] args) {
        JFrame frame = new JFrame("App");
        frame.setContentPane(new App1().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setSize(300, 300);
        frame.setResizable(false);
    }
}
